﻿using System;
using RETAIL_PRICE_ADJUSTMENT___PROMOTION_CONTROL_SYSTEM.Models;
using RETAIL_PRICE_ADJUSTMENT___PROMOTION_CONTROL_SYSTEM.Repositories;
using System.Collections.Generic;
using System.Text;

namespace RETAIL_PRICE_ADJUSTMENT___PROMOTION_CONTROL_SYSTEM.Repositories
{
    public interface IPriceAdjustmentRepository
    {
        void Insert(PriceAdjustment adjustment);
        System.Collections.Generic.List<PriceAdjustment> GetHistoryForProduct(
            int productId);
    }
}
