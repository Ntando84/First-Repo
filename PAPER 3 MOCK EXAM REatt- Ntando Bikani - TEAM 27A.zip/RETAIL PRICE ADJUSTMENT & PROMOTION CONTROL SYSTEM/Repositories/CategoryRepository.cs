﻿using System;
using System.Data.SqlClient;
using RETAIL_PRICE_ADJUSTMENT___PROMOTION_CONTROL_SYSTEM.Data;
using RETAIL_PRICE_ADJUSTMENT___PROMOTION_CONTROL_SYSTEM.Models;
using System.Collections.Generic;
using System.Text;

namespace RETAIL_PRICE_ADJUSTMENT___PROMOTION_CONTROL_SYSTEM.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        public Category FindById(int categoryId)
        {
            using var conn = DatabaseConnection.GetConnection();
            const string sql = @"
                SELECT CategoryId, CategoryName, CategoryDescription
                FROM Category
                WHERE CategoryId = @CategoryId;";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@CategoryId", categoryId);

            conn.Open();
            using var reader = cmd.ExecuteReader();
            if (!reader.Read())
                return null;
            return new Category
            {
                CategoryId = reader.GetInt32(0),
                CategoryName = reader.GetString(1),
                CategoryDescription = reader.IsDBNull(2) ? null : reader.GetString(2)
            };
        }
    }
}
